from assignment5 import *



def colorMain():
    program = create_map_coloring_csp()
    print(program.backtracking_search())




def sudokuMain():
    program = create_sudoku_csp("sudokus/veryhard.txt")
    solution = program.backtracking_search()

    print_sudoku_solution(solution)
    print("\n" + "The backtrack search failed : " + str(program.backtrack_failure) + " times")
    print("\n" + "The backtrack search has been called recursively: " + str(program.backtrack_called) + " times")


#colorMain()

sudokuMain()


